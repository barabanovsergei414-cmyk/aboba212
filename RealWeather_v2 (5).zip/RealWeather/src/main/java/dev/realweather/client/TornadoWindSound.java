package dev.realweather.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/** Зацикленный вой ветра: громкость и высота зависят от близости и силы торнадо. */
public class TornadoWindSound extends AbstractTickableSoundInstance {
    private int quiet = 0;

    public TornadoWindSound() {
        super(RWSounds.TORNADO_WIND, SoundSource.WEATHER, RandomSource.create());
        this.looping = true;
        this.delay = 0;
        this.volume = 0.01f;
        this.relative = true;
        this.attenuation = SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || !ClientStorms.active()) {
            stop();
            return;
        }
        float lvl = ClientStorms.windLevel(mc.player.getX(), mc.player.getZ(), mc.level.getGameTime());
        if (lvl < 0.01f) {
            if (++quiet > 200) { stop(); return; }
        } else {
            quiet = 0;
        }
        float target = Mth.clamp(lvl * 1.4f, 0f, 1f);
        this.volume += (Math.max(target, 0.001f) - this.volume) * 0.08f;
        this.pitch = 0.75f + 0.45f * lvl;
    }
}
